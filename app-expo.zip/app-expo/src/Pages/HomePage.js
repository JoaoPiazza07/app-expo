import React from 'react';
import {View, Text} from 'react-native';

const HomePage = () => {  //função homepage
  return( //conteudo jsx (html)
    <View style={{flex:1, alignItems:'center', justifyContent:'center'}}>

      <Text> Puc Minas </Text>
      

    </View> //funciona como uma div, como conteiner

  );

} 

export default HomePage; //expoprta essa função