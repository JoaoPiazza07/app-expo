import React from 'react';
import {View, Text} from 'react-native';

import HomePage from './src/Pages/HomePage';

const App = () => {  //função homepage
  return( //conteudo jsx (html)

    <HomePage /> //app principal esta enderizando o home page
    
  );

} 

export default App; //expoprta essa função